A Pen created at CodePen.io. You can find this one at https://codepen.io/-__-/pen/NxMpGq.

 Login form animation. Pure CSS, Javascript and Html. 