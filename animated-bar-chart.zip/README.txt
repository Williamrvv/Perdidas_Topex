A Pen created at CodePen.io. You can find this one at https://codepen.io/CreativePunch/pen/AekEC.

 Simple animated bar chart. This could be made purely in CSS once there is support for using attr() with the "height" property. This is proposed and should work in the future, though.